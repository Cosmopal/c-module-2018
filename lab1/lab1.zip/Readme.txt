This is the README for my os refresher lab1 submission.

the lab1demo was a great help to start with libraries. 

First, I made the makefile, eferring from lab1demo.
Then, I used the commands given in lab1demo readme to compile my library.
I tested it using the simple test cases in the main program, by including "str.h"
I then continued to build functions and testing it in main program, adding usages of all the functions.


The following functions are implemented in the str library:

my_strncasecmp
strcpy
my_strncpy
strcat
my_strncat
strcmp
my_strncmp
strchr
strchrnul
strrchr